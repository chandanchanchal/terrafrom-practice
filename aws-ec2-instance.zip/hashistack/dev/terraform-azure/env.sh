# Exporting variables in both cases just in case, no pun intended
export ARM_SUBSCRIPTION_ID="aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
export ARM_CLIENT_ID="bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
export ARM_CLIENT_SECRET="cccccccc-cccc-cccc-cccc-cccccccccccc"
export ARM_TENANT_ID="dddddddd-dddd-dddd-dddd-dddddddddddd"
export subscription_id="aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
export client_id="bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
export client_secret="cccccccc-cccc-cccc-cccc-cccccccccccc"
